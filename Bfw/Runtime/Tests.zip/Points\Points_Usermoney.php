<?php
namespace App\Hbapi\Points;
/**
 * @author Herry
 *
 */
class Points_Usermoney extends Points_Base
{
    
}
?>
