<?php
namespace App\Points\Xdweb;

class Points_User extends Points_Base
{
    
}
?>