<?php
namespace App\Hbapi\Points;
use Lib;
class Points_Hongbao extends Points_Base
{
    
}
?>