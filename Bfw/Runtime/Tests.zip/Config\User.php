<?php
// 店铺状态
$_config_arr['User']['msg'] = [
    "old_pwd_wrong" => "旧密码错误",
    "login_success" => "登录成功",
    "pwd_change_success" => "密码修改成功",
    "reg_success" => "注册成功",
    "not_exsit"=>"用户不存在 ",
    "old_pwd_require"=>"旧密码必须填写",
    "new_pwd_require"=>"新密码必须填写",
    "user_pwd_wrong"=>"用户密码不正确",
    "username_require"=>"用户名必填",
    "pwd_require"=>"密码必填 "
];