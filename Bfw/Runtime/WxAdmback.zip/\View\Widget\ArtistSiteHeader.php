<?php 
use Lib\Bfw;
use Lib\Util\HtmlUtil;
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<script src="/static/js/angular.min.js"></script>
<link rel="stylesheet" href="/static/css/amazeui.min.css" />

