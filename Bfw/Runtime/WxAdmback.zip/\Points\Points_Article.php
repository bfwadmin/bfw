<?php
namespace App\[[DOM]]\Points;

class Points_Article 
{
    
}
?>