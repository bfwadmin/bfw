<?php 
use Lib\Bfw;
use Lib\Util\HtmlUtil;
?>
        </div>

    </div>


   
    <script src="<?=STATIC_FILE_PATH?>/<?=DOMIAN_VALUE?>/js/form.js"></script>
    <script src="<?=STATIC_FILE_PATH?>/<?=DOMIAN_VALUE?>/js/ajaxform.js"></script>
</body>

</html>