<?php
$_config_arr['App'] = [
    "service_remote" => false,
    "web_debug" => false,
    "dbmap" => [
        "Member" => "bfw_member",
        "Group" => "bfw_group",
        "Power" => "bfw_power",
        "Article" => "bfw_article"
    ],
    "tb_pre" => "bfw_"
];

