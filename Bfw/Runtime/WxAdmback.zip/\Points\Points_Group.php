<?php
namespace App\[[DOM]]\Points;
class Points_Group extends Points_Base
{
    
}
?>