<?php
namespace App\[[DOM]]\Points;

class Points_Power extends Points_Base
{
}
?>