jQuery(function( $ ){
    	$('form').ajaxForm({
			// target: '#NoticeDiv',
			success : showResponse
		});
    });
	function showResponse(responseText, statusText, xhr, $form) {
		var resjson = eval("(" + responseText + ")");
		if(resjson['err']){
             alert(resjson['data']);
		}else{
			if (resjson['data'].substr(0, 9) == "redirect:") {
				location.href = resjson['data'].substr(9);
			}else if(resjson['data'].substr(0, 12) =="msgredirect:"){
				var spos=resjson['data'].indexOf("---");
				if(spos>12){
					alert(resjson['data'].substr(12, spos-12));
					var gotohref=resjson['data'].substr(spos+3);
					if(gotohref=="back"){
						history.back();
					}else{
						location.href = gotohref;
					}
				}
			}else if(resjson['data'].substr(0, 4) =="back"){
				history.back();
			}
			else {
				  alert(resjson['data']);
			}

		}
		
	 }
