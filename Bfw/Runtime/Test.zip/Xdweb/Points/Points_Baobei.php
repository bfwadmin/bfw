<?php
namespace App\Xdweb\Points;
use Lib;
class Points_Baobei extends Points_Base
{
    
}
?>