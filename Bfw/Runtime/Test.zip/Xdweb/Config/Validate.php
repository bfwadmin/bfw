<?php
//use App\Client\Cms\Client_Member;
$_config_arr['Validate']['pass'] = [
    "User_WxLogin_Xdweb",
	"User_WxCallback_Xdweb",
];
