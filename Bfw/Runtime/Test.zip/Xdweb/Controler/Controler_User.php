<?php

namespace App\Xdweb\Controler;

use Lib\Bfw;
use Lib\BoControler;
use Lib\Util\UrlUtil;
use Client\Xdweb\Client_User;

/**
 *
 * @author Herry
 *         用户操作
 */
class Controler_User extends BoControler {
	private $AppID = 'wxd959eca309196d66';
	private $AppSecret = '0f03500205d5447bb55a0f947646c4ee';
	
	/**
	 * 获取微信openid
	 */
	function WxOpenid() {
		echo $this->Session ( USER_ID );
	}
	/**
	 * 微信登录
	 * 
	 * @param string $ref        	
	 */
	function WxLogin($ref = "") {
		$callback = Bfw::ACLINK ( "User", "WxCallback", "ref=" . Bfw::UrlCode ( $ref ) );
		$state = md5 ( uniqid ( rand (), TRUE ) );
		$redirect_url = urlencode ( 'http://' . SERVER_NAME . '/' . $callback );
		$_url = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=" . $this->AppID . "&redirect_uri={$redirect_url}&response_type=code&scope=snsapi_base&state={$state}#wechat_redirect";
		header ( "location:{$_url}" );
	}
	
	/**
	 * 微信回调
	 * 
	 * @param string $ref        	
	 */
	function WxCallback($ref = "") {
		if (isset ( $_GET ['code'] )) {
			$json = $this->http_curl ( 'https://api.weixin.qq.com/sns/oauth2/access_token?appid=' . $this->AppID . '&secret=' . $this->AppSecret . '&code=' . $_GET ['code'] . '&grant_type=authorization_code ' );
			$token = json_decode ( $json, 1 );
			if (isset ( $token->errcode )) {
				$this->Error ( "获取openid失败" );
			} else {
				$utypeinfo = Client_User::getInstance ()->GetType ( $token ['openid'] );
				if (! $utypeinfo ['err']) {
					$this->Session ( USER_ADDINFO, $utypeinfo ['data'] ); // 把openid存入session，然后返回页面
				}
				$this->Session ( USER_ID, $token ['openid'] ); // 把openid存入session，然后返回页面
				if ($ref != "") {
					$this->ReDirect ( $ref );
				}
			}
		} else {
			$this->Error ( "获取openid失败" );
		}
	}
	
	/**
	 * http请求
	 * 
	 * @param unknown $url        	
	 * @return Ambiguous
	 */
	private function http_curl($url) {
		$curlobj = curl_init ();
		curl_setopt ( $curlobj, CURLOPT_URL, $url );
		curl_setopt ( $curlobj, CURLOPT_RETURNTRANSFER, 1 );
		curl_setopt ( $curlobj, CURLOPT_SSL_VERIFYPEER, FALSE );
		curl_setopt ( $curlobj, CURLOPT_SSL_VERIFYHOST, FALSE );
		$output = curl_exec ( $curlobj );
		curl_close ( $curlobj );
		return $output;
	}
	
	function Bind($houseid=""){
		
	}
	
	/**
	 * 门店提交
	 */
	function AddMd() {
		if ($this->IsPost ( true )) {
			$_formdata = $this->FormArray ( array (
					"shop_master",
					"master_phone",
					"liense_img"
			), true, "Mendian" );
			if ($_formdata ['err']) {
				return $this->Error ( $_formdata ['data'] );
			}
			$_formdata ['data'] ['add_time'] = UNIX_TIME;
			$_formdata ['data'] ['add_ip'] = IP;
			$_formdata ['data'] ['open_id'] = $this->Session ( USER_ID );
			$_insertdata =Client_User::getInstance ()->AddMd( $_formdata ['data'] );
			if($_insertdata['err']){
				return $this->Error ( Bfw::SelectVal ( $_insertdata ['data'], [
						Client_User::REPEAT => "您已经提交过了",
				] ) );
			}
			return $this->Json(Bfw::RetMsg(false, "提交成功"));
		} else {
			$this->OutCharset ( "utf-8" );
			$this->Display ();
		}
	}
}

?>