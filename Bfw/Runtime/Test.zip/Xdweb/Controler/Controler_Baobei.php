<?php

namespace App\Xdweb\Controler;

use Lib\Bfw;
use Lib\BoControler;
use Lib\Util\UrlUtil;
use App\Xdweb\Client\Client_Baobei;
use Lib\Util\ArrayUtil;
use App\Xdweb\Client\Client_User;

/**
 *
 * @author Herry
 *         报备操作
 */
class Controler_Baobei extends BoControler {
	/**
	 * 报备提交
	 */
	function AddData() {
		Bfw::LogR("ss");
		if ($this->IsPost ( true )) {
			$_formdata = $this->FormArray ( array (
					"id",
					"reg_name",
					"reg_phone",
					"cus_name",
					'cus_phone',
					'look_time',
					'loupan_id',
					"cus_sex"
			), true, "Baobei" );
			if ($_formdata ['err']) {
				return $this->Error ( $_formdata ['data'] );
			}
			$_formdata ['data'] ['reg_time'] = UNIX_TIME;
			$_formdata ['data'] ['reg_ip'] = IP;
			$_formdata ['data'] ['open_id'] = $this->Session ( USER_ID );
			$_insertdata = Client_Baobei::getInstance ()->Insert ( $_formdata ['data'] );
			if ($_insertdata ['err']) {
				return $this->Error ( $_insertdata ['data'] );
			}
			return $this->Alert ( "报备提交成功", array (
					array (
							"返回",
							Bfw::ACLINK ( "Baobei", "ListData" ),
							"" 
					) 
			) );
		} else {
			$this->OutCharset ( "utf-8" );
			$_onedata=Client_Baobei::getInstance()->Cache(5)->DescBy("reg_time")->PageSize(1)->Field("reg_name,reg_phone")->Where("open_id=?",array($this->Session ( USER_ID )))->Select(false);
			if(empty($_onedata['data']['data'])){
				$this->Assign("reg_data", array());
			}else{
				$this->Assign("reg_data", $_onedata['data']['data'][0]);
			}
			$_loupandata=Client_Baobei::getInstance()->Cache(5)->GetLoupan();
			$this->Assign("loupandata", ArrayUtil::ConvertToOne($_loupandata['data']));
			$this->Display ();
		}
	}
	
	/**
	 * 我的报备列表
	 *
	 * @param number $page        	
	 * @return void|multitype:unknown
	 */
	function ListData($page = 0,$keyword="") {
		$pagesize = 10;
		$this->OutCharset ( "utf-8" );
		$_wherestr = "open_id=? and isdeleted=0";
		$_wherearr = array (
				$this->Session ( USER_ID ) 
		);
		if($keyword!=""){
			$_wherestr.=" and cus_name like ?";
			$_wherearr[]="%$keyword%";
		}
		
		$_retdata = Client_Baobei::getInstance ()->Field ( "*" )->Where ( $_wherestr, $_wherearr )->PageNum ( $page )->PageSize ( $pagesize )->DescBy ( "reg_time" )->Select ();
		
		foreach ($_retdata ['data'] ['data'] as &$item){
			if($item['confirm_time']>0){
				$item['status']="已确认";
			}else{
				if($item['look_time']<UNIX_TIME){
					$item['status']="未确认";
				}else{
					$item['status']="待确认";
				}
			}
			if(date("Y-m-d",time())==date("Y-m-d",$item['look_time'])){
				$item['look_time_str']="今天";
				$item['look_time_str_det']=date("H时i分",$item['look_time']);
			}else{
				$item['look_time_str']=date("m月d日H时i分",$item['look_time']);
				$item['look_time_str_det']="";
			}

		}
		
		if ($_retdata ['err']) {
			return $this->Error ( $_orderdata ['data'] );
		}
		if ($this->IsPost ()) {
			return $this->Json(Bfw::RetMsg ( false, $_retdata ['data'] ['data'] ));
		}
		// $this->Assign ( "pagerdata", \App\Lib\Util\PagerUtil::_GenPageData ( $_retdata ['data'] ['count'], $page, $pagesize, 2 ) );
		$this->Assign ( "itemdata", $_retdata ['data'] ['data'] );
		$this->Display ();
	}
	function Detail($id=""){
		$this->OutCharset ( "utf-8" );
		$_data=Client_Baobei::getInstance()->Single($id);
		if($_data['err']||$_data['data']==null){
			return $this->Error("数据错误");
		}
		
		if($_data['data']['open_id']!=$this->Session ( USER_ID ) ){
			return $this->Error("数据无权查看");
		}
		$_data['data']['reg_time']=date("Y-m-d H:i:s",$_data['data']['reg_time']);
		$_data['data']['look_time']=date("Y-m-d H:i:s",$_data['data']['look_time']);
		$_data['data']['confirm_time']=$_data['data']['confirm_time']>0?date("Y-m-d H:i:s",$_data['data']['confirm_time']):"未确认";
		return $this->Json($_data);
		//$this->Assign("itemdata", $_data['data']);
		//$this->Display ();
	}
	/**
	 * 报备确认列表
	 *
	 * @param number $page        	
	 */
	function ListDataAdm($page = 0,$keyword="") {
		$pagesize = 10;
		$this->OutCharset ( "utf-8" );
		
		$_userinfo=$this->Session ( USER_ADDINFO );
		if($_userinfo['utype']!=Client_User::USER_ZHULI){
			return $this->Error("没权限");
		}
		
		$_wherestr = "loupan_id=? and isdeleted=0";
		$_wherearr = array (
				$_userinfo['loupan_id']
		);
		
		if($keyword!=""){
			$_wherestr.=" and reg_name like ?";
			$_wherearr[]="%$keyword%";
		}
		
		$_retdata = Client_Baobei::getInstance ()->Field ( "*" )->Where ( $_wherestr, $_wherearr )->PageNum ( $page )->PageSize ( $pagesize )->DescBy ( "reg_time" )->Select ();
		
		foreach ($_retdata ['data'] ['data'] as &$item){
			if($item['confirm_time']>0){
				$item['status']="已确认";
			}else{
				if($item['look_time']<UNIX_TIME){
					$item['status']="未确认";
				}else{
					$item['status']="待确认";
				}
			}
			if(date("Y-m-d",time())==date("Y-m-d",$item['look_time'])){
				$item['look_time_str']="今天";
				$item['look_time_str_det']=date("H时i分",$item['look_time']);
			}else{
				$item['look_time_str']=date("m月d日H时i分",$item['look_time']);
				$item['look_time_str_det']="";
			}
		
		}
		
		if ($_retdata ['err']) {
			return $this->Error ( $_orderdata ['data'] );
		}
		if ($this->IsPost ()) {
			return $this->Json(Bfw::RetMsg ( false, $_retdata ['data'] ['data'] ));
		}
		// $this->Assign ( "pagerdata", \App\Lib\Util\PagerUtil::_GenPageData ( $_retdata ['data'] ['count'], $page, $pagesize, 2 ) );
		$this->Assign ( "itemdata", $_retdata ['data'] ['data'] );
		$this->Display ();
	}
	
	/**
	 * 报备二维码
	 *
	 * @param string $id        	
	 */
	function Qcode($id = "") {
		Bfw::import ( "Plugin.QRcode" );
		\QRcode::png ( "http://wei.iiihouse.com". Bfw::ACLINK ( "Baobei", "Confirm", "id=" . $id ), false, "L", 4 );
	}
	
	/**
	 * 报备确认
	 *
	 * @param string $id        	
	 */
	function Confirm($id = "") {
		if ($this->IsPost (true)) {
			$_formdata = $this->FormArray ( array (
					"id",
					"lou_zhigu",
					"lou_zhuli",
					"lou_builder",
					'memo',
			), true, "BaobeiConf" );
			if ($_formdata ['err']) {
				return $this->Error ( $_formdata ['data'] );
			}
			$_data = Client_Baobei::getInstance ()->Confirm ( $_formdata ['data'] , $this->Session ( USER_ID ) );
			if ($_data ['err']) {
				return $this->Error ( Bfw::SelectVal ( $_data ['data'], [ 
						Client_Baobei::DATA_NULL => "数据错误",
						Client_Baobei::NO_POWER => "无权限" 
				] ) );
			}
			return $this->Alert ( "确认报备成功", array (
					array (
							"返回",
							Bfw::ACLINK ( "Baobei", "ListData" ),
							""
					)
			) );
			
		}else{
			$this->OutCharset ( "utf-8" );
			$_data=Client_Baobei::getInstance()->Single($id);
			if($_data['err']||$_data['data']==null){
				return $this->Error("数据错误");
			}
			$this->Assign("itemdata", $_data['data']);
			$this->Display ();
		}
	}
	
	/**
	 * 撤销报备
	 *
	 * @param string $id        	
	 */
	function Cancel($id = "") {
		if ($this->IsPost ()) {
			$_data = Client_Baobei::getInstance ()->Cancel ( $id, $this->Session ( USER_ID ) );
			if ($_data ['err']) {
				return $this->Error ( Bfw::SelectVal ( $_data ['data'], [ 
						Client_Baobei::DATA_NULL => "数据错误",
						Client_Baobei::NO_POWER => "无权限" ,
						Client_Baobei::TIME_WRONG => "预约时间前一天内无法撤销"
				] ) );
			}
			return $this->Success ( "操作成功" );
		}
	}
}

?>